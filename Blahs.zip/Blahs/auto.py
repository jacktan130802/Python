import water

if __name__ == "__main__":
    water.auto_water()